HiSole CMT package - FIXED record identity collisions

Root files: [Content_Types].xml, data_schema.xml, data.xml
Entities: account(2), contact(3), knowledgearticle(4), incident(60), incidentresolution(60), knowledgearticleincident(60).

Why earlier imports were short: IDs were derived from non-unique titles/subjects causing duplicate GUIDs.
This version derives IDs from ticketnumber, so duplicates in title text are safe and useful for ML intent clustering.
Title duplicates present (expected for clustering): 15; Resolution subject duplicates: 15.
